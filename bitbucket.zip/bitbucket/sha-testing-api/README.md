##	Requerimientos 
Antes de empezar, debes tener acceso al repositorio de Bitbucket (Solicitando acceso al área de DevSecOps) 

Se debe tener instalado y configurado las siguientes herramientas:  
- JDK 18   [`video1. Instalar JDK`](https://www.youtube.com/watch?v=BkhJWeoU-1Q)  /  [`video2. descarga JDK`](https://www.youtube.com/watch?v=oAin-q1oTDw). Verificar versión: `java -version` y `Echo %JAVA_HOME%`  
- Maven 3.6.3   [`video. Instalar Maven`](https://www.youtube.com/watch?v=qPkrvIGUvtU&t=273s). Verificar versión: `mvn -version` y `Echo %MAVEN_HOME%`     
- Git 2.33.0 or higher [`video. Instalar Git`](https://www.youtube.com/watch?v=7qzV04C5S-k) / [`Link. descarga Git`](https://git-scm.com/). Verificar versión: `git -v`    




## Variables de entorno del sistema

1. Antes de inciar debemos tener configuradas las `Valiables de entorno del sistema`  
     1. Nos vamos al icono de windows  
     2. Escribimos variable
     3. Se mostrara la opción de ` Editar las Variables de entorno del sistema` y la seleccionamos      
![var entorno 1.](https://live.staticflickr.com/65535/52418802184_947b8979f2.jpg "var entorno 1.")  

2. Se mostrara una ventana
     1. Seleccionamos la opción `Variable de entorno...`  
     2. Verificamos que se encuentren las variables de entorno `JAVA_HOME`, `MAVEN_HOME` y `Path`     
![var entorno 2.](https://live.staticflickr.com/65535/52418960170_b1b4034f90_z.jpg "var entorno 2.")  

3. Para ver el datelle de la variable Path  
     1. Seleccionamos la variable `Path`  
     2. Damos clic en `Editar`  
     3. Agregamos o verificamos que la ruta del `JDK este hasta \bin`  
     4. Damos clic en `Aceptar` el cambio de la variable
     5. Damos clic en `Aceptar` para guardar los cambios  
![var entorno 3.](https://live.staticflickr.com/65535/52418976660_c1d620ac82_z.jpg "var entorno 3.")  


4. Para que el sistema tome los cambios reniciamos el equipo  
![reinicio.](https://www.softzone.es/app/uploads-softzone.es/2017/10/reinicio-inesperado-de-Windows-10-655x435.jpg "reinicio.")   
 
## Clonar

En el repositorio del navegador web de Bitbucket damos click en el botón `Clone`

ejemplo: `https://bitbucket.org/gentera-insumos/sha-testing-api/src/master/`

![Bitbucket.](https://live.staticflickr.com/65535/52410033155_f68e0cc823_b.jpg "Bitbucket.")
 

Se va a desplegar una pantalla  
1. Seleccionamos en la esquina superior derecha SSH  
2. copiamos la liga
 
![liga clonar.](https://live.staticflickr.com/65535/52417251012_7c29018838_z.jpg "liga clonar.")



## Creación de credential SSH

1. Nos vamos a la ruta de nuestra carpeta donde vamos a clonar el repositorio, damos click derecho y seleccionamos Git Bash Here    
![Git Bash Here.](https://live.staticflickr.com/65535/52417765796_16c1eaf81b.jpg "Git Bash Here.")


2. Ejecutamos el comando: ssh-keygen –C “nuestro E-mail”  
![SSH keygen.](https://live.staticflickr.com/65535/52417769266_7b324a7179_z.jpg "SSH keygen.")

3. Damos enter, enter, enter hasta que nos muestre lo siguiente:
- Nos mostrará la ruta donde se crearon las claves    
![SSH keygen ok.](https://live.staticflickr.com/65535/52417315642_c92aa47eb5_z.jpg "SSH keygen ok.")

4. Se verifica que esten las claves en la carpeta     
![SSH keygen valid.](https://live.staticflickr.com/65535/52418057459_a70ba778a6_c.jpg "SSH keygen valid.")


## Registrar credential SSH en Bitbucket

1. Nos vamos a Bitbucket a la parte de account y seleccionamos Personal settings     
![Personal settings.](https://live.staticflickr.com/65535/52417780496_d608d718bb_c.jpg "Personal settings.")

2. Seleccionamos SSH Keys y posterior Add Keys     
![Add Keys.](https://live.staticflickr.com/65535/52418294268_153f8cc01f_c.jpg "Add Keys.")

3. Nos vamos al archivo que se creo `.pub`.  (En el paso anterior en el key generamos 2 documentos )  
`1.` Copiamos todo su contenido y lo pegamos en `key`.  
`2.` Copiamos el correo que esta en el key y lo pegamos en Label.  
`3.` Seleccionamos Add key   
![Add Keys.](https://live.staticflickr.com/65535/52418298088_655455c989_z.jpg "Add Keys.")

4. Se muestra el registro de la Key     
![Add Keys show.](https://live.staticflickr.com/65535/52417277567_d0004ff0b6_b.jpg "Add Keys show.")


## Clonado de Repositorio

1. Nos vamos a Git Bash en la ruta donde queremos clonar y ejecutamos el comando de Clone SSH que copiamos en el primer punto de `Clonar` 
![Git Bash Clone.](https://live.staticflickr.com/65535/52417283042_2cc32b47e6_z.jpg "Git Bash Clone.")

2. Tecleamos yes y se va a empezar con el clonado del repositorio  
![Clone Yess.](https://live.staticflickr.com/65535/52418078764_3f086dc904_z.jpg "Clone Yess.")

3. Verificamos que se haya realizado el clonado  
![Verificar clonado.](https://live.staticflickr.com/65535/52418307998_470c633dbb_z.jpg "Verificar clonado.")


## Pruebas Karate
Una vez que se clono el repositorio entramos a la carpeta  

```
     cd sha-testing-api
```

Ejecutamos el siguiente comando para instalar las dependencias  

```
     mvn clean install
```

 Cuando se ejecute el comando, nos mostrara la siguiente ejecución en la salida.

    [INFO] Scanning for projects...
    [INFO] 
    [INFO] ----------------< com.gentera:gentera-karate-incentivo >----------------
    
    [INFO] -------------------------------------------------------
    [INFO]  T E S T S
    [INFO] -------------------------------------------------------
    [INFO] Running driver.TestParallel
    13:04:44.084 [main] INFO  integration.xray.XRayListener - XrayListener created
    13:04:46.458 [main] DEBUG com.intuit.karate.Suite - [config] classpath:karate-config.js
    Karate version: 1.2.0
    ======================================================
    elapsed:   1.84 | threads:    4 | thread time: 0.00
    features:     0 | skipped:    0 | efficiency: 0.00
    scenarios:    0 | passed:     0 | failed: 0
    ======================================================
    HTML report: (paste into browser to view) | Karate version: 1.2.0
    file:///C:/Repositorio/sha-testing-api/target/karate-reports/karate-summary.html
    ===================================================================
    [INFO] Tests run: 1, Failures: 0, Errors: 0, Skipped: 0, Time elapsed: 3.813 s - in driver.TestParallel
    [INFO]
    [INFO] Results:
    [INFO]
    [INFO] Tests run: 1, Failures: 0, Errors: 0, Skipped: 0
    [INFO]
    [INFO]
    [INFO] --- maven-jar-plugin:2.4:jar (default-jar) @ automation-api ---
    [WARNING] JAR will be empty - no content was marked for inclusion!
    [INFO] Building jar: C:\Repositorio\sha-testing-api\target\automation-api-0.0.1-SNAPSHOT.jar
    [INFO]
    [INFO] --- maven-install-plugin:2.4:install (default-install) @ automation-api ---
    [INFO] Installing C:\Repositorio\sha-testing-api\target\automation-api-0.0.1-SNAPSHOT.jar to D:\Users\lpgomez\.m2\repository\com\automation-api\0.0.1-SNAPSHOT\automation-api-0.0.1-SNAPSHOT.jar
    [INFO] Installing C:\Repositorio\sha-testing-api\pom.xml to D:\Users\lpgomez\.m2\repository\com\automation-api\0.0.1-SNAPSHOT\automation-api-0.0.1-SNAPSHOT.pom
    [INFO] ------------------------------------------------------------------------
    [INFO] BUILD SUCCESS
    [INFO] ------------------------------------------------------------------------
    [INFO] Total time:  17.115 s
    [INFO] Finished at: 2022-09-28T13:04:48-05:00
    [INFO] ------------------------------------------------------------------------

Con el siguiente comando ejecutamos los feature que tengan el tag de @anime `tags=@anime` que se encuentran dentro de la carpeta `Demo` 

```
     mvn clean test -Dkarate.options="src/test/java/features_file/Demo/ --tags=@anime" -Dtest=driver.TestParallel -Dkarate.env=DEV -Denvironment=DEV
```

![visual studio code tag.](https://live.staticflickr.com/65535/52409617556_99180500a5_b.jpg "visual studio code tag.")

 Nos mostrara la siguiente ejecución en la salida.

    [INFO] Scanning for projects...
    [INFO] 
    [INFO] ----------------< com.gentera:gentera-karate-incentivo >----------------
    Karate version: 1.2.0
     ======================================================
     elapsed:   3.63 | threads:    4 | thread time: 0.91
     features:     1 | skipped:    0 | efficiency: 0.06
     scenarios:    1 | passed:     1 | failed: 0
     ======================================================

     HTML report: (paste into browser to view) | Karate version: 1.2.0
     file:///C:/Repositorio/sha-testing-api/target/karate-reports/karate-summary.html
     ===================================================================

     sep. 29, 2022 1:09:13 P. M. net.masterthought.cucumber.ReportParser parseJsonFiles
     INFO: File 'C:\Repositorio\sha-testing-api\target\karate-reports\src.test.java.features_file.Demo.anime.anime_quotes.json' contains 1 feature(s)
     [INFO] Tests run: 1, Failures: 0, Errors: 0, Skipped: 0, Time elapsed: 5.351 s - in driver.TestParallel
     [INFO]
     [INFO] Results:
     [INFO]
     [INFO] Tests run: 1, Failures: 0, Errors: 0, Skipped: 0
     [INFO]
     [INFO] ------------------------------------------------------------------------
     [INFO] BUILD SUCCESS
     [INFO] ------------------------------------------------------------------------
     [INFO] Total time:  15.594 s
     [INFO] Finished at: 2022-09-29T13:09:14-05:00
     [INFO] ----------------

Con el siguiente comando ejecutamos todos los `feature` que se encuentran dentro de la `carpeta Demo` 

```
     mvn clean test -Dkarate.options="src/test/java/features_file/Demo/" -Dtest=driver.TestParallel -Dkarate.env=DEV -Denvironment=DEV
```

![visual studio code demo.](https://live.staticflickr.com/65535/52409118157_9acb31736c_b.jpg "visual studio code demo.")


 Nos mostrara la siguiente ejecución en la salida.

 
    Karate version: 1.2.0
     ======================================================
     elapsed:   3.83 | threads:    4 | thread time: 1.92
     features:     2 | skipped:    0 | efficiency: 0.13
     scenarios:    2 | passed:     2 | failed: 0
     ======================================================

     HTML report: (paste into browser to view) | Karate version: 1.2.0
     file:///C:/Repositorio/sha-testing-api/target/karate-reports/karate-summary.html
     ===================================================================

     sep. 29, 2022 1:24:40 P. M. net.masterthought.cucumber.ReportParser parseJsonFiles
     INFO: File 'C:\Repositorio\sha-testing-api\target\karate-reports\src.test.java.features_file.Demo.anime.anime_quotes.json' contains 1 feature(s)
     sep. 29, 2022 1:24:40 P. M. net.masterthought.cucumber.ReportParser parseJsonFiles
     INFO: File 'C:\Repositorio\sha-testing-api\target\karate-reports\src.test.java.features_file.Demo.users.users.json' contains 1 feature(s)
     [INFO] Tests run: 1, Failures: 0, Errors: 0, Skipped: 0, Time elapsed: 5.527 s - in driver.TestParallel
     [INFO]
     [INFO] Results:
     [INFO]
     [INFO] Tests run: 1, Failures: 0, Errors: 0, Skipped: 0
     [INFO]
     [INFO] ------------------------------------------------------------------------
     [INFO] BUILD SUCCESS
     [INFO] ------------------------------------------------------------------------
     [INFO] Total time:  17.937 s
     [INFO] Finished at: 2022-09-29T13:24:41-05:00
     [INFO] ------------------------------------------------------------------------

Una vez ejecutado las pruebas automatizadas, podemos ver la ejecución en un reporte. Para visualizar la información nos vamos a Visual Studio en la ruta: `../target/cucumber-html-reports/overview-features-html` clic derecho en el archivo y seleccionamos `Mostrar en el Explorador de archivos` una vez que muestre la carpeta damos doble clic en el documento `overview-features-html` 

![Karate Report.](https://live.staticflickr.com/65535/52409126772_00a40aedac_b.jpg "Karate Report.")


Se nos va abrir una ventana en el navegador con el reporte.

```
Ejemplo:
``` 

![Karate Report.](https://live.staticflickr.com/65535/52409605491_cccdb10d14_b.jpg "Karate Report.")