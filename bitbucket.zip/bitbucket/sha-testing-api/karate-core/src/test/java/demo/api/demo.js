response.header('foo', 'bar');
response.body = { hello: 'world' };
response.status = 201
