function fn() {
  var config = karate.callSingle('call-single-tag-called.feature@callme');
  return config;
}
