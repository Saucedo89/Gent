function fn() {   
  return { functionFromHookKarateBase: function(){ return 'fromHookKarateBase' } }
}
