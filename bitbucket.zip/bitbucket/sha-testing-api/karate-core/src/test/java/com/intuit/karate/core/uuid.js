function fn(){ return java.util.UUID.randomUUID() + ''; }
