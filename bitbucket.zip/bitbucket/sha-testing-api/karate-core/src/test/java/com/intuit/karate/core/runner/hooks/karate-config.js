function fn() {
  var config = {};
  config.hookTest = true;
  return config;
}
