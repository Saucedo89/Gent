package com.intuit.karate.core;

/**
 *
 * @author pthomas3
 */
public class MockUtils {
    
    public static final byte[] testBytes = new byte[]{15, 98, -45, 0, 0, 7, -124, 75, 12, 26, 0, 9};
    
}
