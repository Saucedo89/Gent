function fn() {   
  return { configSource: 'normal' }
}