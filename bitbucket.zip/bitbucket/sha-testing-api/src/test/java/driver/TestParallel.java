package driver;

import com.intuit.karate.Results;
import com.intuit.karate.Runner;
import com.intuit.karate.core.Tag;
import com.intuit.karate.core.ScenarioResult;
import integration.xray.XRayListener;
import net.masterthought.cucumber.Configuration;
import net.masterthought.cucumber.ReportBuilder;
import org.apache.commons.io.FileUtils;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import utilities.Utils;
import utilities.ZipManagerReports;

import java.io.File;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.stream.Collectors;

import static org.junit.jupiter.api.Assertions.assertEquals;

/**
 *
 * @author pthomas3
 */
// important: do not use @RunWith(Karate.class) !

class TestParallel {
	private final static Logger logger = LoggerFactory.getLogger(TestParallel.class);

	private final String jiraTestPlanKey = System.getProperty("xray.planKey");
	private final String jiraProjectKey = System.getProperty("jira.projectKey");
	private XRayListener xRayListener;
	private List<String> tagsToRunFromJira = null;

	@BeforeAll
	static void beforeClass() throws Exception {
		//TestBase.beforeClass();

	}

	@Test
	void testParallel() {
		if(jiraTestPlanKeyParameterIsEnabled() && jiraProjectKeyParameterIsEnabled()) {
			xRayListener = new XRayListener();
			xRayListener.instanceAndConection(
					xr -> {
						xr.startPlanExecution();
						tagsToRunFromJira = xr.getTagsOfJiraTestPlan();
					});
		}
		Results results;
		if(tagsToRunFromJira != null){
			logger.warn(String.format("Total tests del TestPlan %s en Jira: %s", jiraTestPlanKey, tagsToRunFromJira.size() ));
			String tagsToRunInKarate  = tagsToRunFromJira.stream()
					.map(key -> String.format("%s%s","@", key))
					.collect(Collectors.joining(",", "", ""));

			results = Runner.path("classpath:features_file")
					.tags(tagsToRunInKarate)
					.outputCucumberJson(true)
					.parallel(4);
			generateReport(results.getReportDir(), results);
		} else {
			results = Runner.path("classpath:features_file")
					.outputCucumberJson(true)
					//.outputJunitXml(true)
					.parallel(6);
			generateReport(results.getReportDir(), results);
		}

		if (jiraTestPlanKeyParameterIsEnabled() && jiraProjectKeyParameterIsEnabled()) {
			connectToJiraUsingXray(results);
		}

		//Debe ir al final
		assertEquals(0, results.getFailCount(), results.getErrorMessages());
	}

	static void generateReport(String karateOutputPath, Results results) {
		Collection<File> jsonFiles = FileUtils.listFiles(new File(karateOutputPath), new String[] {"json"}, true);
		if(jsonFiles.size() > 0) {
			List<String> jsonPaths = new ArrayList<>(jsonFiles.size());
			jsonFiles.forEach(file -> jsonPaths.add(file.getAbsolutePath()));
			Configuration config = new Configuration(new File("target"), "ent-bup-test-automation");
			config.addClassifications("Platform", System.getProperty("os.name"));
			config.addClassifications("OS Version", System.getProperty("os.version"));
			config.addClassifications("Executing user", System.getProperty("user.name"));
			config.addClassifications("Environment", System.getProperty("environment"));
			config.addClassifications("Execution time",
					String.valueOf( String.format("%s %s", Utils.formatNumber(results.getTimeTakenMillis()), "ms") ) );

			ReportBuilder reportBuilder = new ReportBuilder(jsonPaths, config);
			reportBuilder.generateReports();
		}
	}

	void connectToJiraUsingXray (Results results) {
		List<Tag> filteredTags = results.getScenarioResults()
				.map(sr -> sr.getScenario().getTags())
				.filter(Objects::nonNull)
				.flatMap(List::stream)
				.filter(tag -> tag.getName().startsWith(jiraProjectKey))
				.collect(Collectors.toList());

		Collections.sort(filteredTags, Comparator.comparingInt(tag -> Integer.parseInt(tag.getName().split("-")[1])));
		logger.warn(String.format("Total tests encontrados y ejecutados en Karate: %s", filteredTags.size() ));

		//xRayListener.instanceAndConection(xr -> xr.startTheTestRun(filteredTags));

		List<List<ScenarioResult>> scenarioResults = results.getFeatureResults()
				.map(fr -> fr.getScenarioResults())
				.collect(Collectors.toList());

		Map<String, Boolean> scenarioStatus = new HashMap<>();

		for (List<ScenarioResult> features : scenarioResults) {
			features.forEach(scenario ->
					{
						ScenarioResult executedScenario = new ScenarioResult(scenario.getScenario());
						executedScenario.addStepResults(scenario.getStepResults());
						//Scenario Passed:true/false
						Boolean isSuccessful = !executedScenario.isFailed();
						if (executedScenario.getScenario().getTags() != null) {
							scenarioStatus.putAll(
									executedScenario.getScenario().getTags()
											.stream()
											.filter(tag -> tag.getName().startsWith(jiraProjectKey))
											.collect(Collectors.toMap(Tag::getName, (t) -> isSuccessful)));
						}
					}
			);
		}

		ZipManagerReports zipFilesEvidence = new ZipManagerReports();
		zipFilesEvidence.zipDirectory(zipFilesEvidence.getDirectoryReports(), zipFilesEvidence.generateNameToZip());

		xRayListener.instanceAndConection(xr -> xr.finishTestRun(filteredTags, scenarioStatus, zipFilesEvidence.getAbsPathReportsZip()));
	}


	private boolean jiraTestPlanKeyParameterIsEnabled() {
		return jiraTestPlanKey != null;
	}

	private boolean jiraProjectKeyParameterIsEnabled() {
		return jiraProjectKey != null;
	}

}
