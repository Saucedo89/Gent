package data;

public class Person {

}
