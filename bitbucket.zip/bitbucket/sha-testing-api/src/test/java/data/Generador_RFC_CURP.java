package data;

import org.apache.commons.lang.StringUtils;

import java.util.Arrays;
import java.util.Random;

public class Generador_RFC_CURP {

	// ------------------------------ FIELDS ------------------------------
	
    public static final String[] MESES =
        {"Ene", "Feb", "Mar", "Abr", "May", "Jun", "Jul", "Ago", "Sep", "Oct", "Nov", "Dec"};

    public static final String[] MESES_VALOR = {"01", "02", "03", "04", "05", "06", "07", "08", "09", "10", "11", "12"};

    public static String[] ENTIDAD_FEDERATIVA = {"AGUASCALIENTES",
                                                 "BAJA CALIFORNIA NTE.",
                                                 "BAJA CALIFORNIA SUR",
                                                 "CAMPECHE",
                                                 "COAHUILA",
                                                 "COLIMA",
                                                 "CHIAPAS",
                                                 "CHIHUAHUA",
                                                 "DISTRITO FEDERAL",
                                                 "DURANGO",
                                                 "GUANAJUATO",
                                                 "GUERRERO",
                                                 "HIDALGO",
                                                 "JALISCO",
                                                 "MEXICO",
                                                 "MICHOACAN",
                                                 "MORELOS",
                                                 "NAYARIT",
                                                 "NUEVO LEON",
                                                 "OAXACA",
                                                 "PUEBLA",
                                                 "QUERETARO",
                                                 "QUINTANA ROO",
                                                 "SAN LUIS POTOSI",
                                                 "SINALOA",
                                                 "SONORA",
                                                 "TABASCO",
                                                 "TAMAULIPAS",
                                                 "TLAXCALA",
                                                 "VERACRUZ",
                                                 "YUCATAN",
                                                 "ZACATECAS",
                                                 "SERV. EXTERIOR MEXICANO",
                                                 "NACIDO EN EL EXTRANJERO"};

    public static String[] ENTIDAD_FEDERATIVA_VALOR = {"AS",
                                                       "BC",
                                                       "BS",
                                                       "CC",
                                                       "CL",
                                                       "CM",
                                                       "CS",
                                                       "CH",
                                                       "DF",
                                                       "DG",
                                                       "GT",
                                                       "GR",
                                                       "HG",
                                                       "JC",
                                                       "MC",
                                                       "MN",
                                                       "MS",
                                                       "NT",
                                                       "NL",
                                                       "OC",
                                                       "PL",
                                                       "QT",
                                                       "QR",
                                                       "SP",
                                                       "SL",
                                                       "SR",
                                                       "TC",
                                                       "TS",
                                                       "TL",
                                                       "VZ",
                                                       "YN",
                                                       "ZS",
                                                       "SM",
                                                       "NE"};


    private static char[] VOCALS = {'A', 'E', 'I', 'O', 'U'};

    private static Random random = new Random();


	// -------------------------- STATIC METHODS --------------------------

	public static String generaCURP(String primerApellido, String segundoApellido, String nombres, String genero,
			String fechaDeNacimiento, String entidadDeNacimiento) throws Exception {
		// limpiar los datos
		primerApellido = trim(primerApellido);
		segundoApellido = trim(segundoApellido);
		nombres = trim(nombres);
		genero = trim(genero);
		entidadDeNacimiento = trim(entidadDeNacimiento);

		// validar que los datos estan correctors
		String error = validarDatos(primerApellido, segundoApellido, nombres, genero, fechaDeNacimiento,
				entidadDeNacimiento);
		if (error != null) {
			throw new Exception(error);
		}
		
		String materno = "";
		if (segundoApellido.isEmpty()) {
			materno = "XX";
		} else {
			materno = segundoApellido;
		}

		// generar Curp
		//curp.append(fechaDeNacimiento.substring(8, 10));
		//curp.append(fechaDeNacimiento.substring(0, 2));
		//curp.append(fechaDeNacimiento.substring(3, 5));
		String curp = String.valueOf(primerApellido.charAt(0)) +
				primeraVocal(primerApellido.substring(1)) +
				materno.charAt(0) +
				nombres.charAt(0) +
				fechaDeNacimiento.substring(6) +
				fechaDeNacimiento.substring(2, 4) +
				fechaDeNacimiento.substring(0, 2) +
				genero +
				entidadDeNacimiento +
				primeraLetra(primerApellido.substring(1)) +
				//primeraLetra(segundoApellido.substring(1)) +
				primeraLetra(materno.substring(1)) +
				primeraLetra(nombres.substring(1)) +
				0 +
				random.nextInt(10);
		curp = curp.replaceAll("Ñ", "N");
		//System.out.println(">>>>>>>>>>>>>>>>>> curp: " + curp);
		return curp;
	}

	public static String generaRFC(String paterno, String materno, String nombres, 
			String fechaDeNacimiento) throws Exception {
		// limpiar los datos
		paterno = trim(paterno);
		materno = trim(materno);
		nombres = trim(nombres);

		// validar que los datos estan correctors
		String error = validarDatos(paterno, materno, nombres, "", fechaDeNacimiento,
				"");
		if (error != null) {
			throw new Exception(error);
		}

		// generar RFC
		//rfc.append(fechaDeNacimiento.substring(8, 10));
		//rfc.append(fechaDeNacimiento.substring(0, 2));
		//rfc.append(fechaDeNacimiento.substring(3, 5));
		
		String materno2 = "";
		if (materno.isEmpty()) {
			materno2 = "X";
		} else {
			materno2 = materno;
		}

		String rfc = String.valueOf(paterno.charAt(0)) +
				primeraVocal(paterno.substring(1)) +
				materno2.charAt(0) +
				nombres.charAt(0) +
				fechaDeNacimiento.substring(6) +
				fechaDeNacimiento.substring(2, 4) +
				fechaDeNacimiento.substring(0, 2);
		//System.out.println(">>>>>>>>>>>>>>>>>> rfc: " + rfc);
		return rfc;
	}

	private static String trim(String s) {
		return StringUtils.trimToEmpty(s).toUpperCase();
	}

	private static char primeraLetra(String s) {
		int i = StringUtils.indexOfAnyBut(s, VOCALS);
		if (i >= 0) {
			return s.charAt(i);
		}
		return 'X';
	}

	private static char primeraVocal(String s) {
		int i = StringUtils.indexOfAny(s, VOCALS);
		if (i >= 0) {
			return s.charAt(i);
		}
		return 'X';
	}

	private static String validarDatos(String primerApellido, String segundoApellido, String nombres, String sexo,
			String fechaDeNacimiento, String entidadDeNacimiento) {
		if ("".equals(primerApellido)) {
			return "Primer apellido es obligatorio";
		}
		
		if (!StringUtils.isAlpha(primerApellido)) {
			return "Primer apellido no valido, caracteres validos: A-Z (incluso �)";
		}

		/*if ("".equals(segundoApellido)) {
			return "Segundo apellido es obligatorio";
		}*/
		
		if (!StringUtils.isAlpha(segundoApellido)) {
			return "Segundo apellido no valido, caracteres validos: A-Z (incluso �)";
		}

		if ("".equals(nombres)) {
			return "Nombre(s) es obligatorio";
		}
		if (!StringUtils.isAlphaSpace(nombres)) {
			return "Nombre(s) no valido, caracteres validos: A-Z (incluso �)";
		}

		if (!sexo.isEmpty() && !"H".equals(sexo) && !"M".equals(sexo)) {
			return "Sexo no valido";
		}

		if ("".equals(fechaDeNacimiento)) {
			return "Fecha de nacimiento no valido";
		}

		//if ("".equals(entidadDeNacimiento)) {
		//	return "Entidad de nacimiento es obligatorio";
		//}
		
		if (!entidadDeNacimiento.isEmpty() && !Arrays.asList(ENTIDAD_FEDERATIVA_VALOR).contains(entidadDeNacimiento)) {
			return "Entidad de nacimiento necesita ser la abreciacion";
		}
		return null;
	}
}
