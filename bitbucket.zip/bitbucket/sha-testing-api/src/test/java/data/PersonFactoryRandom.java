package data;

public class PersonFactoryRandom implements PersonFactory {

	@Override
	public Person createPerson() {
		return null;
	}

	@Override
	public Person createPerson(String genero) {
		return null;
	}

}
