package data;

public interface PersonFactory {

    Person createPerson();

    Person createPerson(String genero);
}
