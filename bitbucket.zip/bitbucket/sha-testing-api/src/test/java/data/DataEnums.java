package data;


public class DataEnums {
    public enum Genero {
        MASCULINO(1),
        FEMENINO(2);

        private int id;

        Genero(int id) { this.id = id; }
        public int getValue() { return id; }
    }
}
