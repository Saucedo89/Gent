package features_file.Demo.users;

import com.intuit.karate.junit5.Karate;

class AnimeRunner {
    
    @Karate.Test
    Karate testUsers() {
        return Karate.run("users").relativeTo(getClass());
    }    

}
