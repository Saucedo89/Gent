select lb.id_persona from transactional.lego_basico lb
inner join transactional.lego_minimo lm
on lb.id_persona = lm.id_persona
where lm.ind_primer_nombre_validado and DATE(lm.primer_nombre_ult_fecha_verif) = current_date
and lm.ind_segundo_nombre_validado and DATE(lm.segundo_nombre_ult_fecha_verif) = current_date
and lm.ind_apellido_paterno_validado and DATE(lm.apellido_paterno_ult_fecha_verif) = current_date
and lm.ind_apellido_materno_validado and DATE(lm.apellido_materno_ult_fecha_verif) = current_date
and lb.ind_fecha_nacimiento_validada and DATE(lb.fecha_nacimiento_ult_fecha_verif) = current_date
and lb.rfc = substring(lb.curp,1,10) and lb.ind_rfc_validado = false and lb.rfc_ult_fecha_verif isnull
and lb.id_pais_nacimiento = 1  and lb.id_nacionalidad = 1
and lb.id_persona = <idPersonToVerify>;