select lb.id_persona from transactional.lego_basico lb
inner join transactional.lego_minimo lm
on lb.id_persona = lm.id_persona
where lm.ind_primer_nombre_validado isnull
and lm.ind_segundo_nombre_validado isnull
and lm.ind_apellido_paterno_validado isnull
and lm.ind_apellido_materno_validado isnull
and lb.ind_fecha_nacimiento_validada isnull
and lb.ind_rfc_validado isnull
and lb.id_persona = <idPersonToVerify>;