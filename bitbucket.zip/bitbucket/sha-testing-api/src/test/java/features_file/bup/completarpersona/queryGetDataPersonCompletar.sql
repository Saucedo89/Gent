select lb.id_persona, transactional.persona.ind_completar_persona, lb.iub, lb.id_estatus_enrolamiento, t.tiempo_inactividad, lb.fecha_creacion
	from transactional.persona
    inner join transactional.lego_basico lb on transactional.persona.id_persona = lb.id_persona
    inner join transactional.lego_totales_credito t on t.id_persona = lb.id_persona
where lb.curp = <CurpToVerify>;