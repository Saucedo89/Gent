DO $$
   declare
       id integer := <idPersonToDeleteInTheBUP>;
   begin
       delete from identitycore.master_person where id_persona = id;
       delete from transactional.persona_relacion
       where id_lego_basico = (select id_lego_basico from transactional.lego_basico where id_persona = id);
       delete from transactional.lego_basico where id_persona = id;
       delete from transactional.lego_minimo where id_persona = id;
       delete from transactional.historico_persona_domicilio where id_persona = id;
       delete from transactional.persona_domicilio where id_persona = id;
       delete from transactional.historico_persona_email where id_persona = id;
       delete from transactional.persona_email where id_persona = id;
       commit;
   end;
$$;