select * from transactional.persona p  left join
transactional.lego_segmentadores lb on lb.id_persona =p.id_persona 
where lb.id_persona  is null limit 1;