select p.id_persona from transactional.persona p  left join
transactional.lego_gentera_servicios lb on lb.id_persona =p.id_persona 
where lb.id_persona  is null limit 1;